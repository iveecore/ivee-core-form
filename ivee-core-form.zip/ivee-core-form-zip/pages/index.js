import React, { useState } from 'react'

export default function Form() {
  const [step, setStep] = useState(0)
  const [role, setRole] = useState('')
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    whatsapp: '',
  })
  const [answers, setAnswers] = useState({})
  const [result, setResult] = useState(null)
  const [loading, setLoading] = useState(false)

  const roles = ['Developer', 'Recruiter', 'Business Dev', 'AI Engineer', 'Operations']

  const sharedQuestions = [
    { id: 'q1', text: 'Tell us about your most relevant experience for this role?', type: 'text' },
    { id: 'q2', text: 'What are your salary expectations?', type: 'text' },
    { id: 'q3', text: 'Why do you want to join Ivee Core?', type: 'text' },
  ]

  const roleQuestions = {
    Developer: [
      { id: 'q4', text: 'What programming languages do you know?', type: 'text' },
      { id: 'q5', text: 'Experience with React/Next.js?', type: 'text' },
    ],
    Recruiter: [
      { id: 'q4', text: 'How many candidates have you placed?', type: 'text' },
      { id: 'q5', text: 'Your best recruiting story?', type: 'text' },
    ],
    'Business Dev': [
      { id: 'q4', text: 'Biggest deal you closed?', type: 'text' },
      { id: 'q5', text: 'Your sales process?', type: 'text' },
    ],
    'AI Engineer': [
      { id: 'q4', text: 'AI/ML experience level?', type: 'text' },
      { id: 'q5', text: 'Favorite AI model or framework?', type: 'text' },
    ],
    Operations: [
      { id: 'q4', text: 'Systems youve built or optimized?', type: 'text' },
      { id: 'q5', text: 'Biggest operational challenge solved?', type: 'text' },
    ],
  }

  const calculateScore = (ans) => {
    let score = 0
    Object.values(ans).forEach((answer) => {
      if (answer && answer.trim().length > 20) score += 15
      else if (answer && answer.trim().length > 10) score += 10
      else if (answer && answer.trim().length > 0) score += 5
    })
    return Math.min(100, score)
  }

  const getLevel = (score) => {
    if (score < 50) return 'Entry'
    if (score < 70) return 'Junior'
    if (score < 85) return 'Mid'
    if (score < 95) return 'Senior'
    return 'Lead'
  }

  const getSalaryRange = (level) => {
    const ranges = {
      Entry: '$20K - $35K',
      Junior: '$30K - $50K',
      Mid: '$50K - $80K',
      Senior: '$80K - $120K',
      Lead: '$120K - $180K+',
    }
    return ranges[level]
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)

    const score = calculateScore(answers)
    const level = getLevel(score)
    const salary_range = getSalaryRange(level)

    try {
      const res = await fetch('/api/submit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: formData.name,
          email: formData.email,
          whatsapp: formData.whatsapp,
          role,
          score,
          level,
          salary_range,
          answers,
        }),
      })

      const data = await res.json()
      if (res.ok) {
        setResult({ score, level, salary_range })
        setStep('result')
      } else {
        alert('Error: ' + data.error)
      }
    } catch (error) {
      alert('Submission failed: ' + error.message)
    } finally {
      setLoading(false)
    }
  }

  // Role Selection
  if (step === 0) {
    return (
      <div style={{ maxWidth: '600px', margin: '50px auto', padding: '20px', fontFamily: 'sans-serif' }}>
        <h1>🚀 Ivee Core - Apply Now</h1>
        <p>Select your role:</p>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px' }}>
          {roles.map((r) => (
            <button
              key={r}
              onClick={() => {
                setRole(r)
                setStep(1)
              }}
              style={{
                padding: '15px',
                fontSize: '16px',
                backgroundColor: '#185FA5',
                color: 'white',
                border: 'none',
                borderRadius: '8px',
                cursor: 'pointer',
              }}
            >
              {r}
            </button>
          ))}
        </div>
      </div>
    )
  }

  // Info & Questions
  if (step === 1) {
    return (
      <div style={{ maxWidth: '600px', margin: '50px auto', padding: '20px', fontFamily: 'sans-serif' }}>
        <h2>Tell us about yourself</h2>
        <form onSubmit={() => setStep(2)}>
          <input
            type="text"
            placeholder="Full Name"
            required
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            style={{ width: '100%', padding: '10px', marginBottom: '10px', fontSize: '14px' }}
          />
          <input
            type="email"
            placeholder="Email"
            required
            value={formData.email}
            onChange={(e) => setFormData({ ...formData, email: e.target.value })}
            style={{ width: '100%', padding: '10px', marginBottom: '10px', fontSize: '14px' }}
          />
          <input
            type="tel"
            placeholder="WhatsApp (optional)"
            value={formData.whatsapp}
            onChange={(e) => setFormData({ ...formData, whatsapp: e.target.value })}
            style={{ width: '100%', padding: '10px', marginBottom: '20px', fontSize: '14px' }}
          />
          <button type="submit" style={{ width: '100%', padding: '12px', backgroundColor: '#185FA5', color: 'white', border: 'none', borderRadius: '8px', cursor: 'pointer', fontSize: '16px' }}>
            Next
          </button>
        </form>
      </div>
    )
  }

  // Questions
  if (step === 2) {
    const currentQuestions = [...sharedQuestions, ...(roleQuestions[role] || [])]
    return (
      <div style={{ maxWidth: '600px', margin: '50px auto', padding: '20px', fontFamily: 'sans-serif' }}>
        <h2>Questions for {role}</h2>
        <form onSubmit={handleSubmit}>
          {currentQuestions.map((q) => (
            <div key={q.id} style={{ marginBottom: '20px' }}>
              <label style={{ display: 'block', marginBottom: '8px', fontWeight: 'bold' }}>
                {q.text}
              </label>
              <textarea
                required
                value={answers[q.id] || ''}
                onChange={(e) => setAnswers({ ...answers, [q.id]: e.target.value })}
                style={{ width: '100%', padding: '10px', minHeight: '80px', fontSize: '14px', fontFamily: 'sans-serif' }}
              />
            </div>
          ))}
          <button
            type="submit"
            disabled={loading}
            style={{
              width: '100%',
              padding: '12px',
              backgroundColor: loading ? '#ccc' : '#185FA5',
              color: 'white',
              border: 'none',
              borderRadius: '8px',
              cursor: loading ? 'not-allowed' : 'pointer',
              fontSize: '16px',
            }}
          >
            {loading ? 'Submitting...' : 'Submit & Get Score'}
          </button>
        </form>
      </div>
    )
  }

  // Result
  if (step === 'result' && result) {
    return (
      <div style={{ maxWidth: '600px', margin: '50px auto', padding: '20px', fontFamily: 'sans-serif', textAlign: 'center' }}>
        <h1>🎉 Your Results</h1>
        <div style={{ fontSize: '48px', fontWeight: 'bold', color: '#185FA5', margin: '20px 0' }}>
          {result.score}/100
        </div>
        <p style={{ fontSize: '20px', fontWeight: 'bold' }}>Level: {result.level}</p>
        <p style={{ fontSize: '18px' }}>Estimated Salary: {result.salary_range}</p>
        <p style={{ fontSize: '14px', color: '#666', marginTop: '30px' }}>
          We will review your application and contact you within 48 hours.
        </p>
        <button
          onClick={() => {
            setStep(0)
            setRole('')
            setAnswers({})
            setResult(null)
          }}
          style={{
            marginTop: '20px',
            padding: '12px 30px',
            backgroundColor: '#185FA5',
            color: 'white',
            border: 'none',
            borderRadius: '8px',
            cursor: 'pointer',
            fontSize: '16px',
          }}
        >
          Apply for Another Role
        </button>
      </div>
    )
  }
}
