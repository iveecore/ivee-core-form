import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY
)

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' })
  }

  try {
    const { name, email, whatsapp, role, score, level, salary_range, answers } = req.body

    const { data, error } = await supabase
      .from('candidates')
      .insert([
        {
          name,
          email,
          whatsapp,
          role,
          score,
          level,
          salary_range,
          all_answers: answers,
          ip_address: req.headers['x-forwarded-for'] || req.socket.remoteAddress,
        },
      ])
      .select()

    if (error) {
      return res.status(400).json({ error: error.message })
    }

    return res.status(200).json({ success: true, data })
  } catch (error) {
    return res.status(500).json({ error: 'Internal server error' })
  }
}
