# Ivee Core Form

Secure recruitment intake system for Ivee Core.

## Features

- Multi-role adaptive form
- Real-time AI scoring
- Encrypted candidate data (Supabase)
- Zero cost infrastructure

## Setup

1. Create `.env.local` from `.env.example`
2. Add Supabase credentials
3. Run: `npm install && npm run dev`
4. Visit: http://localhost:3000

## Database

Create this table in Supabase:

```sql
CREATE TABLE candidates (
  id BIGSERIAL PRIMARY KEY,
  name VARCHAR(255),
  email VARCHAR(255) UNIQUE,
  whatsapp VARCHAR(20),
  role VARCHAR(50),
  score INTEGER,
  level VARCHAR(50),
  salary_range VARCHAR(100),
  all_answers JSONB,
  created_at TIMESTAMP DEFAULT NOW(),
  ip_address VARCHAR(45)
);
```

## Deploy to Vercel

1. Push to GitHub
2. Go to vercel.com
3. Import this GitHub repo
4. Add environment variables
5. Deploy

## Support

Email: vee0iveecore@gmail.com
